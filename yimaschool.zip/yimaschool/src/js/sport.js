function sportJs(ops){
    this.ele = ops || ops.ele;

    this.pos = {
        disy : 0,           //开始的 y 坐标
        disY : 0,           //结束的 Y 坐标
        longSize:0,         //移动的距离
        transformTime :.5+'s ease-out',  //动画执行的速度
        maxLongSize : this.ele.children().height() - $("#yiMaLi3").height()          //获取内容的高度
    }
    this.init();
}
sportJs.prototype.init = function(){

    this.bindEven();
}
sportJs.prototype.bindEven = function(){
    var _this = this;

    var maxUlLengths = $("#yiMaUl").children().length;
    var maxUlLength = -(($("#yiMaUl").children().eq(2).height())*(maxUlLengths-1)+$("#yiMaUl").children().eq(0).height())+$(window).height();


    console.log(maxUlLength)

    var evenFun = {
        start : function(e){
            e.preventDefault();

            _this.pos.longSize = 0;
            //console.log(_this.pos.longSize )

            _this.pos.disy = e.touches[0].clientY;                                          //开始的y坐标
            _this.pos.setTop = _this.ele.children().offset().top;                           //盒子距离顶部的距离

            _this.ele.children().css({'-webkit-transition':'none'});


        },
        move : function(e){
            e.preventDefault();

            _this.pos.disY = e.touches[0].clientY;                                          //move是的Y坐标

            _this.pos.longSize = _this.pos.disY - _this.pos.disy + _this.pos.setTop;        //move时滑动的长度



            _this.pos.direction = (_this.pos.disY - _this.pos.disy) < 0 ? "up" : "down";        //滑动的方向

            console.log(_this.pos.longSize)

            if(_this.pos.longSize >= 0){
                _this.pos.longSize = 0;
            }else  if(_this.pos.longSize <= maxUlLength){
                _this.pos.longSize = maxUlLength;

            }
            //盒子move 时移动的样式
            _this.ele.find("#yiMaUl").css({'-webkit-transform':'translate3d(0,'+ _this.pos.longSize +'px,0)'});




        },
        end : function(){
            if(_this.pos.direction == "up"){
                _this.pos.longSize = _this.pos.longSize + (_this.pos.disY - _this.pos.disy)*2;
            }else if(_this.pos.direction == "down"){
                _this.pos.longSize = _this.pos.longSize + Math.abs(_this.pos.disY - _this.pos.disy)*2;
            }
            console.log($("#yiMaUl").height());
            if(_this.pos.longSize >= 0){
                _this.pos.longSize = 0;
            }else  if(_this.pos.longSize <= maxUlLength){
                _this.pos.longSize = maxUlLength;

            }

            _this.pos.size = Math.abs(_this.pos.disY - _this.pos.disy);     //总共走的距离

            _this.pos.speed = _this.pos.size / _this.pos.timeSize;          //滑动的速度


            //盒子end 时移动的样式
            _this.ele.children().css({'-webkit-transform':'translate3d(0,'+ _this.pos.longSize +'px,0)','-webkit-transition':'-webkit-transform '+_this.pos.transformTime});

        }
    }
    this.ele.on("touchstart",evenFun.start);
    $(document).on("touchmove",evenFun.move);
    this.ele.on("touchend",evenFun.end);
}