(function($){

    var  itemTimer = null;
    var AllTimer = function(cb){
        if(itemTimer){
            clearTimeout(itemTimer);
        }
        itemTimer = setTimeout(function(){
            cb && cb();
        },150);

    }

    var sportTime = 1;

    var headHeight = $("#headtitle").height();
    var heights = $("#navbox").height();//获取切换tab的高度
    //给导航添加色块
    $("#nav").css("position","relative");
    var selectedBox  = '<div class="selectedBox" id="selectedBox"></div>';//添加选中块
    $("#nav").append(selectedBox);

    var ops = {
        selectedWidth : $("#nav").find("li").width(),       //选中状态框的宽
        selectedHeight : $("#nav").find("li").height(),     //选中状态框的高
        selectBgColor : '#fbaacb',                         //选中状态框的背景色
        selectBgImg:null,                               //选中状态框的背景图片
        selectBgImgSize : "100% 100%",                  //选中状态框的背景图片大小
        ZIndex:-1,                                       //选中状态框Zindex值

    }
    $("#selectedBox").css({
        'width':ops.selectedWidth+'px',
        'height':ops.selectedHeight+'px',
        'position':'fixed',
        'left':50+'%',
        'top':0,
        'margin-left':-ops.selectedWidth/2+'px',
        'z-index':ops.ZIndex,
        'background': ops.selectBgImg != null ? 'url('+ops.selectBgImg+') no-repeat' : ops.selectBgColor,
        'background-size': ops.selectBgImgSize,
        'border-left':'1px solid #000',
        'border-right':'1px solid #000',
        'box-sizing':'border-box'

    });
    //给导航添加点击事件
    var timer = null;
    var setScrollTop = function(data){
        itemScrollTop = $("#masterContent").children().eq(data).offset().top;

        clearInterval(timer);
        var longSize = $("body")[0].scrollTop;
        var speed = Math.abs(itemScrollTop - longSize) * sportTime * 0.01;
        console.log(speed)
        var step = 3;
        timer=setInterval(function(){
            if(itemScrollTop > longSize){
                longSize+=step;
                if(longSize >= itemScrollTop){
                    longSize = itemScrollTop;
                    clearInterval(timer);
                }
            }else{
                longSize-=step;
                if(longSize <= itemScrollTop){
                    longSize = itemScrollTop;
                    clearInterval(timer);
                }
            }

            $("body")[0].scrollTop = longSize - 50;

        },speed);
        //$("body")[0].scrollTop = itemScrollTop*1 - heights/6;

    }
    var liEventFun = function(e){

        $(this).css("color",'#fff').siblings().css("color",'#000');
        //e.preventDefault();
        var Index = $(this).index();
        var liWidth = $(this).width();
        var sizeLength = 0;
        if(Index == 0){
            sizeLength = (Index+1) * liWidth;
            console.log(Index,sizeLength)
        }else{
            sizeLength = -(Index-1) * liWidth;

        }
        //$("#nav")[0].scrollLeft = -(Index-1) * liWidth;
        $(this).parent().css({
            '-webkit-transform':'translate3d('+sizeLength+'px,0,0)',
            '-webkit-transition':'all '+sportTime+'s'
        });
        setScrollTop(Index);
        AllTimer(function(){
            AllTimer(function(){
                $("#nav")[0].scrollLeft = 0;
            });
        });

    }
    var itemScrollTop = "";
    $("ul").on("click","li",liEventFun);


    var ops = {
        sx : 0, //开始坐标
        mx : 0,  //移动时的坐标
        setLeft : 0,//盒子左边的距离
    }

    var navMoveFun = {
        start : function(e){
            var $this = $(this);
            ops.sx = e.touches[0].clientX;

            ops.setLeft = $this.offset().left;

            console.log(ops)

        },
        move : function(e){
            //e.preventDefault();
            ops.mx = e.touches[0].clientX;

        },
        end : function(e){
            var $this = $(this);



        }
    }
    $("#lists").on("touchstart",navMoveFun.start);
    $("#lists").on("touchmove",navMoveFun.move);
    $("#lists").on("touchend",navMoveFun.end);


    //tab切换

    var scrollTopHeight = 0;//获取屏幕卷上去的高度
    var singleListWidth = $(".list").width();//获取单个Ii的宽度


    var navSport = function(x){
        $("#lists").css({"-webkit-transform":'translate3d('+x+'px,0,0)','-webkit-transition':'-webkit-transform 0.5s'});
    }

    var isNavShow = function(){
        scrollTopHeight = $("body")[0].scrollTop;


        if(scrollTopHeight+50 >= headHeight){
            $("#navbox").css({
                'visibility': 'visible',
                '-webkit-transform':'translate3d(0,'+heights+'px,0)',
                '-webkit-transition':'-webkit-transform .2s'
            });
            if($("#lists").has("isScroll")){
                for(var i=0;i<$(".list").length;i++){
                    var setTTop = $("#masterContent").children().eq(i).offset().top// + 200;
                    if(scrollTopHeight <= setTTop){
                        navSport(-singleListWidth*(i-1));
                        $("#lists").children().eq(i).css("color",'#fff').siblings().css("color",'#000');
                        break;
                    }
                }
            }



        }else{
            $("#navbox").css({
                '-webkit-transform':'translate3d(0,0,0)',
                '-webkit-transition':'-webkit-transform .2s'

            }).on("webkitTranstionEnd",function(){
                $("#navbox").css({
                    'visibility': 'hidden'

                });
            });
        }

    }
    isNavShow();
    $(window).on("scroll",function(){
        $("#lists").addClass("isScroll")
        AllTimer(function(){
            isNavShow();
            AllTimer(function(){
                $("#lists").removeClass("isScroll");
            });
        });
    });

    $("#smallSchool").on("click",function(){
        alert(5555)
    });




    //渲染页面
    api.Index({},function(data){
        var data = data.data;
        var ohtml = "";

        var isRead = "<span>已读</span>";//是否点击
        var noOpen = '<div class="noOpen"><p>该模块暂未开放。</p><p>若您喜欢姨妈学院,请点击下方按钮!</p><span class="hope"></span></div>';

        $.each(data,function(key,val){
            ohtml = "";
            if(val.text == "小学"){
                $.each(val.data,function(k,v){
                    ohtml += '<p class="open" data-id='+ v.id +' data-topicId='+ v.topicId +'>'+ v.title;
                    if(v.isRead == true){
                        ohtml += isRead;
                    }
                    ohtml += '</p>';
                });
                $("#smallSchool").find(".schoolCenter").html(ohtml);
            }
            if(val.text == "初中"){
                $.each(val.data,function(k,v){

                    ohtml += '<p class="open" data-id='+ v.id +' data-topicId='+ v.topicId +'>'+ v.title;
                    if(v.isRead == true){
                        ohtml += isRead;
                    }
                    ohtml += '</p>';
                });

                $("#middleSchool").find(".schoolCenter").html(ohtml);
            }
            if(val.text == "高中"){
                $.each(val.data,function(k,v){

                    ohtml += '<p class="open" data-id='+ v.id +' data-topicId='+ v.topicId +'>'+ v.title;
                    if(v.isRead == true){
                        ohtml += isRead;
                    }
                    ohtml += '</p>';
                });
                $("#highSchool").find(".schoolCenter").html(ohtml);
            }
            if(val.text == "大学"){
                $.each(val.data,function(k,v){

                    ohtml += '<p class="open" data-id='+ v.id +' data-topicId='+ v.topicId +'>'+ v.title;
                    if(v.isRead == true){
                        ohtml += isRead;
                    }
                    ohtml += '</p>';
                });
                $("#university").find(".schoolCenter").html(ohtml);
            }
            if(val.text == "研究生"){
                $.each(val.data,function(k,v){

                    ohtml += '<p class="open" data-id='+ v.id +' data-topicId='+ v.topicId +'>'+ v.title;
                    if(v.isRead == true){
                        ohtml += isRead;
                    }
                    ohtml += '</p>';
                });
                if(val.isOpen == false){
                    $("#graduateSchool").find(".schoolCenter").html(noOpen);
                    //我很期待
                    if(val.apply == true){
                        $("#graduateSchool").find(".support").addClass("support");
                    }
                }else{
                    $("#graduateSchool").find(".schoolCenter").html(ohtml);
                }


            }
            if(val.text == "博士生"){
                $.each(val.data,function(k,v){
                    ohtml += '<p class="open" data-id='+ v.id +' data-topicId='+ v.topicId +'>'+ v.title;
                    if(v.isRead == true){
                        ohtml += isRead;
                    }
                    ohtml += '</p>';
                });
                if(val.isOpen == false){

                    $("#doctorSchool").find(".schoolCenter").html(noOpen);
                    //我很期待
                    if(val.apply == true){
                        $("#doctorSchool").find(".support").addClass("support");
                    }
                }else{
                    $("#doctorSchool").find(".schoolCenter").html(ohtml);
                }

            }
        });



    },function(){
        alert("网络错误");
    });

    //给话题添加点击事件
    $("#masterContent").on("click",".open",function(){
        var topicid = $(this).data("topicid");

        api.readtopic({
            topicid : topicid

        },function(data){

        },function(){
            alert("网络错误");
        });
        alert("dayima://topic/"+topicid);
        window.location.href = "dayima://topic/"+topicid;
    });

    //我很期待按钮
    $("#masterContent").on("click",".noOpen .hope",function(){
        var stage = $(this).parent().parent().parent().index()+1;

        api.apply({
            stageval : stage
        },function(data){
            if(data.errno == 0){
                $("#masterContent").children().eq(stage-1).find(".hope").addClass("support");
            }else{
                alert("网络错误");
            }

        },function(){
            alert("网络错误");
        });
    });









})(Zepto);