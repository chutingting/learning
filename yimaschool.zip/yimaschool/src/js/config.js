var env = $("meta[name=env]").attr("content") || "product";

var debug = false;
var marketDomain,missDomain,img_domain,welfare_Domain;
var api_url;

var welfareDomain=document.domain;

var envs={
    "${env}":function(){
        debug = true;
        img_domain = 'http://pv.event.test.yoloho.com';
        marketDomain='http://marketing.test.yoloho.com';
        missDomain='https://mall1.test.meiyue.com';
        /*welfare_Domain =  "http://welfare.event.test.yoloho.com";
        api_url = "http://welfare.event.yoloho.com";*/
        welfare_Domain =  "http://college.event.yoloho.com";
        api_url = "http://college.event.test.yoloho.com";

    },
    "develop":function(){
        debug = false;
        img_domain = 'http://pv.event.test.yoloho.com';
        marketDomain='http://marketing.test.yoloho.com';
        missDomain='https://mall1.test.meiyue.com';
        welfare_Domain =  "http://"+welfareDomain+":8083";
        api_url = "http://"+welfareDomain+":8083";
    },
    "test":function(){
        debug = true;
        img_domain = 'http://pv.event.test.yoloho.com';
        marketDomain='http://marketing.test.yoloho.com';
        missDomain='https://mall1.test.meiyue.com';
        welfare_Domain =  "http://"+welfareDomain;
        api_url = "http://"+welfareDomain;
    },
    "product":function(){
        debug = false;
        img_domain = 'http://pv.event.yoloho.com';
        marketDomain='http://marketing.yoloho.com';
        missDomain='https://ibuy.meiyue.com';
        welfare_Domain =  "http://"+welfareDomain;
        api_url = "http://"+welfareDomain;
    }
};
(envs[env])();

var api = $.network({
    'Index':{url: '/college/topicData', type: 'POST', dataType: 'json'},
    'readtopic':{url: '/college/readtopic', type: 'GET', dataType: 'json'},
    'apply':{url: '/college/apply', type: 'GET', dataType: 'json'},


}, {
    debug: debug,
    isJson: false,
    develoment_url: [api_url, ""],				//开发模式
    product_url: [api_url, ""]			            //生产模式
});

var addUid=function(url,uid,token){
    if(url.indexOf('ibuy')>=0||url.indexOf('mall')>=0){
        if(url.indexOf('?')>0){
            return url+'&d-uid='+uid+'&d-token='+token;
        }else {
            return url+'?d-uid='+uid+'&d-token='+token;
        }
    }else {
        if(url.indexOf('?')>0){
            return url+'&uid='+uid+'&token='+token;
        }else {
            return url+'?uid='+uid+'&token='+token;
        }
    }
};
