// +----------------------------------------------------------------------
// | Tjs [ Sucry 自己改造的js库  此文件一般改造系统变量for Html5 ] 基于jquery
// +----------------------------------------------------------------------
// | v1.6.2 release  2014.12.18
// +----------------------------------------------------------------------
// | Copyright (c) 2014-2015 http://www.dayima.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Sucry <sqboytan@126.com><tankang@dayima.com>
// +----------------------------------------------------------------------

/*************************************************************************
 * 引入fastclick
 *************************************************************************/


/*

window.addEventListener('load', function() {
  FastClick.attach(document.body);
}, false);
*/



/*************************************************************************
 *
 * 改造系统alert
 * param  str  传入要弹出的str
 *          pos  弹出的位置        1
 *                            2
 *                            3
 * return false
 * creat by zwn
 *************************************************************************/
window.alert = function (str){
    if (document.getElementById("tAlert") || !str) {
        return false;
    }
    var html;
    html ='<style id="tAlertStyle">#tAlert div{font-size: 12px; }[data-dpr="2"] #tAlert div {font-size: 24px; }@media all and (-webkit-device-pixel-ratio: 2) and (min-width: 1080px) {[data-dpr="2"] #tAlert div {font-size: 48px; } }[data-dpr="3"] #tAlert div {font-size: 36px; }@media all and (-webkit-device-pixel-ratio: 3) and (min-width: 1620px) {[data-dpr="3"] #tAlert div {font-size: 72px; } }@media all and (-webkit-device-pixel-ratio: 1) and (min-width: 540px) {#tAlert div {font-size: 24px; } }</style>'+
        '<div style="text-align: center;position:fixed;top: 1.6rem;z-index: 100;width:100%;" id="tAlert">'+
        '<div style="padding:0.10667rem 0.37333rem;max-width: 5.33333rem;z-index: 99;text-shadow: none;display: inline-block;line-height: 1.5em;background:#000;color:#fff;border-radius:0.16rem;opacity: 0.8;word-break: break-all; ">'+
        str+
        '</div>'+
        '</div>';
    var $dialog = $(html);
    $("body").append($dialog);
    setTimeout(function () {
        $("#tAlert").remove();
        $("#tAlertStyle").remove();
    }, 2000);
    return false;
}