(function(){
    $.fn.tabFun = function(options){
        var $this = $(this);

        var defaults = {
            selectedWidth : $this.find("li").width(),       //选中状态框的宽
            selectedHeight : $this.find("li").height(),     //选中状态框的高
            selectBgColor : 'pink',                         //选中状态框的背景色
            selectBgImg:null,                               //选中状态框的背景图片
            selectBgImgSize : "100% 100%",                  //选中状态框的背景图片大小
            ZIndex:1,                                       //选中状态框Zindex值
            callBack : function(){
                console.log("点击事件");
            }

        }
        var ops = $.extend(defaults,options);

        function tabFun(){

            //this.init();
            this.initDom();
            this.Event();

        }
        /*tabFun.prototype.init = function(){
         }*/
        tabFun.prototype.initDom = function(){
            $this.css("position","relative");
            var selectedBox  = '<div class="selectedBox" id="selectedBox"></div>';//添加选中块

            $this.append(selectedBox);

            $("#selectedBox").css({
                'width':ops.selectedWidth+'px',
                'height':ops.selectedHeight+'px',
                'position':'fixed',
                'left':50+'%',
                'top':0,
                'margin-left':-ops.selectedWidth/2+'px',
                'z-index':ops.ZIndex,
                'background': ops.selectBgImg != null ? 'url('+ops.selectBgImg+') no-repeat' : ops.selectBgColor,
                'background-size': ops.selectBgImgSize

            });

        }
        tabFun.prototype.Event = function(){
            var clickFun = function(e){
                e.preventDefault();
                var Index = $(this).index();
                var liWidth = $(this).width();
                var sizeLength = 0;
                if(Index == 0){
                    sizeLength = (Index+1) * liWidth;
                }else{
                    sizeLength = -(Index-1) * liWidth;
                }

                $(this).parent().css({
                    '-webkit-transform':'translate3d('+sizeLength+'px,0,0)',
                    '-webkit-transition':'-webkit-transform .2s'
                });
                var data = {
                    zIndex : Index
                }
                ops.callBack(data);
            }
            $this.find("li").on("click",clickFun);

        }


        this.each(function(){
            new tabFun();
        });
    }
})(Zepto);
