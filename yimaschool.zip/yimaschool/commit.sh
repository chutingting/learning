#!/bin/sh
if [ "$#" -lt 1 ] #判断一下参数的个数对不对
 then
       echo '没有javaWeb路径参数'
       echo '例子: sh commit_trade.sh ../javaWeb'
       exit
fi
echo '删除build'
rm -rf build &&
echo 'done'
echo '正在gulp'
gulp default &&
echo '开始复制'
cp ./build/*.html $1/WEB-INF/template &&
cp -r ./build/minsrc/src/css $1/resources &&
cp -r ./build/minsrc/src/js $1/resources &&
cp -r ./build/minsrc/src/images $1/resources &&
cp -r ./build/minsrc/src/font $1/resources &&
echo 'done'
cd $1 &&
echo 'git 状态'
git status